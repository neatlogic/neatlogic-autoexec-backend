# REST::Client
REST::Client module for CPAN.

See http://search.cpan.org/perldoc?REST::Client
